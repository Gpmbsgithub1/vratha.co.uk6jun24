               <div class="sidebar_blog_2">
                  <h4>General</h4>
                  <ul class="list-unstyled components">
                    <li><a href="<?php echo base_url('AdminController/display_users');?>"><i class="fa fa-table purple_color2"></i> <span>User Management</span></a></li>
                    
                     
                  </ul>
               </div>